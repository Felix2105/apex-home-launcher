APEX TERMUX:WIDGET SHORTCUTS

Install Termux:Widget from the same trusted source/signature family as your Termux app.
In Termux, copy the scripts into ~/.shortcuts/ and mark them executable:

mkdir -p ~/.shortcuts
cp ~/storage/shared/Download/termux-widget/*.sh ~/.shortcuts/ 2>/dev/null
chmod +x ~/.shortcuts/*.sh

If the ZIP was extracted somewhere else, change the source path to the actual extracted termux-widget directory. Widget scripts must live in ~/.shortcuts/ (or ~/.shortcuts/tasks/ for grouped shortcuts). Add the Termux:Widget to the Android home screen and tap a shortcut.

These scripts reuse the existing ~/start-apex-final.sh and do not replace or delete the original APEX installation. Confirm paths if your installed copy differs.
