#!/data/data/com.termux/files/usr/bin/bash
out='APEX STATUS'
if curl -fsS --max-time 3 http://127.0.0.1:8080/ >/dev/null 2>&1; then out="$out\nDashboard: ONLINE"; else out="$out\nDashboard: OFFLINE"; fi
if curl -fsS --max-time 3 http://127.0.0.1:8765/api/health >/dev/null 2>&1; then out="$out\nBackend: ONLINE"; else out="$out\nBackend: OFFLINE"; fi
printf '%b\n' "$out"
printf '%b\n' "$out" > "$HOME/apex-widget-status.txt"
termux-toast "APEX status saved to ~/apex-widget-status.txt" 2>/dev/null || true
