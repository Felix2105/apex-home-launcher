#!/data/data/com.termux/files/usr/bin/bash
am start -a android.intent.action.VIEW -d 'http://127.0.0.1:8080/business-hq.html' >/dev/null 2>&1
