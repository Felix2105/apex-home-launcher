#!/data/data/com.termux/files/usr/bin/bash
termux-wake-lock 2>/dev/null || true
nohup "$HOME/start-apex-final.sh" >> "$HOME/apex-widget-start.log" 2>&1 &
sleep 3
am start -a android.intent.action.VIEW -d 'http://127.0.0.1:8080/' >/dev/null 2>&1 || true
