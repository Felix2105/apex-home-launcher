# APEX Linux Mobile — Ubuntu Touch-inspired Android launcher

This is an Android launcher APK project for Samsung Galaxy A20 / Android 11. It keeps Android installed and uses Termux for Linux tools and the existing APEX local services.

## Design direction
- Ubuntu Touch / Lomiri-inspired clean full-screen workspace and app grid
- APEX navy-and-gold visual identity
- Touch-friendly cards for Dashboard, Business HQ, Linux status, family, files, and settings
- Native Home launcher intent filter; choose APEX Home in Android default Home app settings
- Termux:Widget scripts are in `termux-widget/`

## Build on GitHub using your phone
1. Create a repository named `apex-home-launcher`.
2. Upload the contents of this folder (`settings.gradle`, `build.gradle`, `gradle.properties`, `app/`, `.github/`, and `termux-widget/`) to the repository root. Do not upload only this README.
3. Open Actions and run **Build APEX Home APK** (or push to `main`).
4. Open the completed workflow run, download artifact `APEX-Home-Launcher-debug-apk`, extract it, and install `app-debug.apk`.
5. Select Settings → Apps → Choose default apps → Home app → APEX Home.

## Important
The APK source is not a compiled APK. GitHub Actions builds it. Local dashboard pages require the existing APEX services in Termux to be running at `127.0.0.1:8080` and backend health at `127.0.0.1:8765`.
