package com.apex.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class WebPanelActivity extends Activity {
    private WebView web;
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(7,17,31)); getWindow().setNavigationBarColor(Color.rgb(7,17,31));
        String url = getIntent().getStringExtra("url"); String title = getIntent().getStringExtra("title");
        if (url == null || !(url.startsWith("http://127.0.0.1:8080/") || url.equals("http://127.0.0.1:8765/api/health"))) { Toast.makeText(this,"Only local APEX addresses are allowed",Toast.LENGTH_LONG).show(); finish(); return; }
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(7,17,31));
        TextView bar = new TextView(this); bar.setText("‹   APEX HOME     /     " + (title == null ? "PANEL" : title)); bar.setTextColor(Color.rgb(212,175,55)); bar.setTextSize(14); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(16),0,dp(8),0); root.addView(bar,new LinearLayout.LayoutParams(-1,dp(52))); bar.setOnClickListener(v -> finish());
        web = new WebView(this); web.setBackgroundColor(Color.WHITE); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.setWebViewClient(new WebViewClient()); root.addView(web,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); web.loadUrl(url);
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
