package com.apex.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** APEX Home: Ubuntu Touch-inspired workspace, implemented as a safe Android launcher. */
public class MainActivity extends Activity {
    private final int bg = Color.rgb(13, 20, 31);
    private final int panel = Color.rgb(27, 39, 55);
    private final int panel2 = Color.rgb(35, 49, 67);
    private final int gold = Color.rgb(220, 183, 86);
    private final int white = Color.rgb(245, 247, 250);
    private final int muted = Color.rgb(174, 187, 202);
    private float downX;
    private int page = 0;
    private LinearLayout root;
    private TextView pageLabel;

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), Color.rgb(55, 70, 88)); return d;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(0);
        build();
    }
    private void build() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(bg);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24)); scroll.addView(root);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brandCol = new LinearLayout(this); brandCol.setOrientation(LinearLayout.VERTICAL);
        TextView brand = text("APEX", 32, gold, true); brandCol.addView(brand);
        brandCol.addView(text("LINUX MOBILE  /  WORKSPACE", 10, muted, true));
        header.addView(brandCol, new LinearLayout.LayoutParams(0, -2, 1));
        TextView emblem = text("◈", 36, gold, true); emblem.setGravity(Gravity.CENTER);
        header.addView(emblem, new LinearLayout.LayoutParams(dp(54), dp(54))); root.addView(header);
        TextView greeting = text("Your phone. Your workspace.", 18, white, true);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, dp(48)); gp.topMargin = dp(12); root.addView(greeting, gp);
        TextView hint = text("Swipe left or right to move between spaces", 12, muted, false);
        root.addView(hint, new LinearLayout.LayoutParams(-1, dp(24)));
        pageLabel = text("  ◉  HOME SPACE        ○  APP SPACE", 11, gold, true);
        pageLabel.setBackground(shape(panel, 24)); pageLabel.setPadding(dp(14), 0, dp(14), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(42)); lp.topMargin = dp(10); lp.bottomMargin = dp(12); root.addView(pageLabel, lp);
        root.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { downX = e.getX(); return true; }
            if (e.getAction() == MotionEvent.ACTION_UP) {
                float dx = e.getX() - downX;
                if (Math.abs(dx) > dp(70)) { page = dx < 0 ? 1 : 0; showPage(); return true; }
            }
            return true;
        });
        showPage(); setContentView(scroll);
    }
    private void showPage() {
        // Keep the header and page switcher, replace the content cards below them.
        while (root.getChildCount() > 5) root.removeViewAt(5);
        pageLabel.setText(page == 0 ? "  ◉  HOME SPACE        ○  APP SPACE" : "  ○  HOME SPACE        ◉  APP SPACE");
        if (page == 0) {
            addSection("YOUR SPACES", "Open your APEX workspace or management tools");
            addTile("▦", "APEX DASHBOARD", "Your existing local command centre", "http://127.0.0.1:8080/");
            addTile("▤", "BUSINESS HQ", "Clients · jobs · quotes · invoices", "http://127.0.0.1:8080/business-hq.html");
            addTile("⌘", "LINUX SERVICE STATUS", "Check the local APEX backend", "http://127.0.0.1:8765/api/health");
            addTile("♡", "FAMILY & PERSONAL", "A space for life beyond business", null);
            addBottomNote();
        } else {
            addSection("APP SPACE", "Quick access to the tools on your phone");
            addTile("▣", "OPEN ANDROID APPS", "Return to Android and launch installed apps", null);
            addTile("⌁", "TERMUX LINUX", "Use Termux for shell commands and Linux tools", null);
            addTile("▱", "FILES & DOCUMENTS", "Open Android file picker", null);
            addTile("⚙", "SET APEX AS HOME", "Choose APEX as the default launcher", "HOME_SETTINGS");
            addTile("↻", "SERVICE STARTUP HELP", "Open instructions for starting local services", "HELP");
            addBottomNote();
        }
    }
    private void addSection(String title, String desc) {
        TextView h = text(title, 11, gold, true); root.addView(h, new LinearLayout.LayoutParams(-1, dp(28)));
        TextView d = text(desc, 12, muted, false); root.addView(d, new LinearLayout.LayoutParams(-1, dp(32)));
    }
    private void addTile(String symbol, String title, String desc, String url) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(14), dp(12), dp(14), dp(12)); card.setBackground(shape(panel, 18));
        TextView icon = text(symbol, 26, gold, true); icon.setGravity(Gravity.CENTER);
        card.addView(icon, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout words = new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL); words.setPadding(dp(12), 0, 0, 0);
        words.addView(text(title, 14, white, true));
        TextView description = text(desc, 11, muted, false); words.addView(description);
        card.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(text("›", 26, gold, true), new LinearLayout.LayoutParams(dp(24), dp(42)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(78)); p.bottomMargin = dp(10); root.addView(card, p);
        card.setOnClickListener(v -> openTarget(url));
    }
    private void openTarget(String url) {
        if (url == null) {
            Toast.makeText(this, "This space is a design placeholder. Android and Termux remain available.", Toast.LENGTH_LONG).show(); return;
        }
        if ("HOME_SETTINGS".equals(url)) {
            try { startActivity(new Intent(android.provider.Settings.ACTION_HOME_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Settings → Apps → Default apps → Home app", Toast.LENGTH_LONG).show(); }
            return;
        }
        if ("HELP".equals(url)) {
            Toast.makeText(this, "Start APEX using your existing Termux startup script, then reopen this page.", Toast.LENGTH_LONG).show(); return;
        }
        Intent i = new Intent(this, WebPanelActivity.class); i.putExtra("url", url); i.putExtra("title", "APEX Workspace"); startActivity(i);
    }
    private void addBottomNote() {
        TextView note = text("ANDROID CORE  ·  TERMUX LINUX TOOLS  ·  APEX WORKSPACE", 10, muted, true);
        note.setGravity(Gravity.CENTER); note.setPadding(dp(4), dp(14), dp(4), dp(10)); root.addView(note);
        TextView safety = text("APEX is a launcher, not an operating-system replacement. Your existing Android and Termux installation stay in place.", 11, muted, false);
        safety.setGravity(Gravity.CENTER); root.addView(safety);
    }
}
