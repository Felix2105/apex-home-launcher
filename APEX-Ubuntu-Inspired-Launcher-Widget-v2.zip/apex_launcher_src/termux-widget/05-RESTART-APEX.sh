#!/data/data/com.termux/files/usr/bin/bash
# Reuse the existing startup script; this does not delete project files or databases.
nohup "$HOME/start-apex-final.sh" >> "$HOME/apex-widget-start.log" 2>&1 &
termux-toast 'APEX startup requested. Use APEX STATUS shortly.' 2>/dev/null || true
